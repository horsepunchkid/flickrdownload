package com.aetrion.flickr.machinetags;

import com.aetrion.flickr.SearchResultList;

/**
 * 
 * @author mago
 * @version $Id: NamespacesList.java,v 1.2 2009/07/12 22:43:07 x-mago Exp $
 */
public class NamespacesList extends SearchResultList {
    private static final long serialVersionUID = 12L;
}
