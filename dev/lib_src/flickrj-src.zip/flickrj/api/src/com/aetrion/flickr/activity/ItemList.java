package com.aetrion.flickr.activity;

import com.aetrion.flickr.SearchResultList;

public class ItemList extends SearchResultList {

    public ItemList() {
    }

}
