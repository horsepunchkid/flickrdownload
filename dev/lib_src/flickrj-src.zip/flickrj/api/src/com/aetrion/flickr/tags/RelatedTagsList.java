/*
 * Copyright (c) 2005 Aetrion LLC.
 */

package com.aetrion.flickr.tags;

import java.util.ArrayList;

/**
 * @author Anthony Eden
 */
public class RelatedTagsList extends ArrayList {
    private static final long serialVersionUID = 12L;

    private String source;

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

}
