package com.aetrion.flickr.photocollections;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.aetrion.flickr.FlickrException;
import com.aetrion.flickr.Parameter;
import com.aetrion.flickr.Response;
import com.aetrion.flickr.Transport;
import com.aetrion.flickr.auth.AuthUtilities;
import com.aetrion.flickr.photosets.Photoset;

/**
 * Interface for working with collections.
 *
 * @author Brian Masney
 * @version $Id$
 */
public class PhotoCollectionsInterface {

    public static final String METHOD_GET_TREE = "flickr.collections.getTree";
    public static final String METHOD_GET_INFO = "flickr.collections.getInfo";

    private String apiKey;
    private String sharedSecret;
    private Transport transportAPI;

    public PhotoCollectionsInterface(String apiKey, String sharedSecret, Transport transportAPI) {
        this.apiKey = apiKey;
        this.sharedSecret = sharedSecret;
        this.transportAPI = transportAPI;
    }

    public List<PhotoCollection> getTree(String userId) throws IOException, SAXException, FlickrException {
        List parameters = new ArrayList();
        parameters.add(new Parameter("method", METHOD_GET_TREE));
        parameters.add(new Parameter("api_key", this.apiKey));

        if (userId != null) {
            parameters.add(new Parameter("user_id", userId));
        }
        if (AuthUtilities.isAuthenticated(parameters)) {
            parameters.add(
                new Parameter(
                    "api_sig",
                    AuthUtilities.getSignature(this.sharedSecret, parameters)
                )
            );
        }

        Response response = this.transportAPI.get(this.transportAPI.getPath(), parameters);
        if (response.isError()) {
            throw new FlickrException(response.getErrorCode(), response.getErrorMessage());
        }
        Element photosetsElement = response.getPayload();
        List<PhotoCollection> photoCollections = new ArrayList();
        NodeList photoCollectionElements = photosetsElement.getElementsByTagName("collection");
        for (int i = 0; i < photoCollectionElements.getLength(); i++) {
            Element photoCollectionElement = (Element) photoCollectionElements.item(i);
            PhotoCollection photoCollection = new PhotoCollection();
            photoCollection.setId(photoCollectionElement.getAttribute("id"));
            photoCollection.setTitle(photoCollectionElement.getAttribute("title"));
            photoCollection.setDescription(photoCollectionElement.getAttribute("description"));
            photoCollection.setIconLarge(photoCollectionElement.getAttribute("iconlarge"));
            photoCollection.setIconSmall(photoCollectionElement.getAttribute("iconsmall"));

            List<Photoset> sets = new ArrayList<Photoset>();
            NodeList setElements = photoCollectionElement.getElementsByTagName("set");
            for (int j = 0; j < setElements.getLength(); j++) {
                Element setElement = (Element) setElements.item(j);
                Photoset set = new Photoset();
                set.setId(setElement.getAttribute("id"));
                set.setTitle(setElement.getAttribute("title"));
                set.setDescription(setElement.getAttribute("description"));
                sets.add(set);
            }
            photoCollection.setSets(sets);
            photoCollections.add(photoCollection);
        }
        return photoCollections;
    }
}
