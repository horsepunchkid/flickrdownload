package com.aetrion.flickr.photocollections;

import java.util.List;

import com.aetrion.flickr.photosets.Photoset;

public class PhotoCollection {
	private String id;
	private String title;
	private String description;
	private String iconLarge;
	private String iconSmall;
	private List<Photoset> sets;
	
	public String getId() {
		return this.id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return this.title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return this.description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getIconLarge() {
		return this.iconLarge;
	}
	public void setIconLarge(String iconLarge) {
		this.iconLarge = iconLarge;
	}
	public String getIconSmall() {
		return this.iconSmall;
	}
	public void setIconSmall(String iconSmall) {
		this.iconSmall = iconSmall;
	}	
	public List<Photoset> getSets() {
		return this.sets;
	}
	public void setSets(List<Photoset> sets) {
		this.sets = sets;
	}
}
