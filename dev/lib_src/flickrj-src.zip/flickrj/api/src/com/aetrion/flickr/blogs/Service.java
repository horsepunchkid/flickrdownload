package com.aetrion.flickr.blogs;

/**
 * 
 * @author mago
 * @version $Id: Service.java,v 1.2 2009/07/12 22:43:07 x-mago Exp $
 */
public class Service {
	private static final long serialVersionUID = 12L;

	private String id;
    private String name;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
